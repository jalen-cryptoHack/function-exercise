import UIKit

func calculator (num1: Int, num2: Int) -> Int {
    var results = 0
    results = num1 + num2
    
    return results
}
var total = calculator(num1: 36, num2: 12)
print("36 + 12 = \(total)")
